# -*- coding: utf-8 -*-
import seqmining
import json
import os
import sys
import copy
reload(sys)
sys.setdefaultencoding('utf-8')

#read json from .json
def myreadjson(data_path):
	with open(data_path,'r') as f:
		data = json.load(f)
		return data

# write json in txt
def mywritejson(save_path,content):
	content = json.dumps(content,indent=4,ensure_ascii=False)
	with open(save_path,'w') as f:
		f.write(content)

# 生成序列函数
def genSeq(lists):
	res = lists[0]
	lens = 0
	if len(lists) >= 4:
		lens = 4
	else:
		lens = len(lists)
	for i in range(1,lens):
		res = seqTwo(res,lists[i])
	# print res
	return res


def seqTwo(seq0,seq1):
	res = []
	for i in range(len(seq0)):
		for j in range(len(seq1)):
			res.append(seq0[i]+"->"+seq1[j])
	return res



if  __name__ == "__main__":		
	patient_seqs_data = myreadjson("/home/ninghan/Desktop/cohort_sequence_analytics/pymining/pymining/pymining/temp.json")
	# print patient_seqs_data["Data"]["Similarities"]
	finalres = []
	wholeseq = []
	pa_simi = []
	pa_simi = patient_seqs_data["Data"][0]["Similarities"]
	for i in pa_simi:
		pid = i["PID"]
		refTime = i["RefTime"]
		sequences = []
		sequences = i["Sequences"]
		datelist = []
		patientseqlist = []
		stagelist = []
		for j in range(0,len(sequences)):
			if (sequences[j]["DD"] not in datelist) and (sequences[j]["DD"] >= refTime):
				datelist.append(sequences[j]["DD"])
				if len(stagelist) != 0:
					patientseqlist.append(copy.copy(stagelist))
				stagelist = []
				if sequences[j].get("FTYPE"):
					stagelist.append(sequences[j]["NAMECN"])
			elif sequences[j]["DD"] >= refTime:
				if sequences[j].get("FTYPE"):
					stagelist.append(sequences[j]["NAMECN"])
		patientseqlist.append(copy.copy(stagelist))
		# print patientseqlist
		# break		
		wholeseq.append(copy.copy(patientseqlist))
	for m in range(len(wholeseq)):
		finalres = finalres + genSeq(wholeseq[m])
	for n in range(len(finalres)):
		finalres[n] = finalres[n].split("->")
	# print finalres
	freq_seqs = []
	freq_seqs = sorted(seqmining.freq_seq_enum(finalres, 100))
	ss = []
	for ii in freq_seqs:
		tt = {}
		if len(ii[0]) >= 1:
			tt["patterns"] = ii[0]
			tt["nums"] = ii[1]
			# tt[ ",".join(ii[0]) ] = ii[1]
			ss.append( tt )
	ss = sorted(ss, key=lambda xx: xx["nums"],reverse = True) 
	mywritejson("/home/ninghan/Desktop/cohort_sequence_analytics/pymining/pymining/pymining/L2_S100_P1.json",ss)
	#print sorted(freq_seqs)