# -*- coding: utf-8 -*-
from pymining import itemmining, assocrules, perftesting,seqmining
import json
import os
import sys
import copy
reload(sys)
sys.setdefaultencoding('utf-8')

#read json from .json
def myreadjson(data_path):
	with open(data_path,'r') as f:
		data = json.load(f)
		return data

# write json in txt
def mywritejson(save_path,content):
	content = json.dumps(content,indent=4,ensure_ascii=False)
	with open(save_path,'w') as f:
		f.write(content)

if  __name__ == "__main__":		
	patient_seqs_data = myreadjson("/home/ninghan/Desktop/cohort_sequence_analytics/patient sequence/seqs_nums.json")
	# print patient_seqs_data
	seqs = [ ["a","d","c","d"],["d","c"]]
	relim_input = itemmining.get_fptree(patient_seqs_data,"",500)
	item_sets = itemmining.fpgrowth(relim_input, min_support=500)
	# print item_sets
	# rules = assocrules.mine_assoc_rules(item_sets, min_support=1000, min_confidence=0.11)
	# # print rules
	# for i in rules:
	# 	if len(i[0]) > 1:
	# 		print i[0]
	ss = []
	for ii in item_sets:
		if len(ii) > 1:
			mm = []
			nn = {}
			for jj in ii:
				mm.append(jj)
			nn["patterns"] = mm
			nn["nums"] = item_sets[ii]	
			ss.append(nn)
	mywritejson("/home/ninghan/Desktop/cohort_sequence_analytics/patient sequence/seqs__rules_mining_results.json",ss)